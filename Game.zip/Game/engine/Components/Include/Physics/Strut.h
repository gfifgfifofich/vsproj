#pragma once
void Strut(ball* a, ball* b, float StrutLength, bool Draw = false);
void MStrut(ball* a, ball* b, float StrutLength, bool Draw = false);

