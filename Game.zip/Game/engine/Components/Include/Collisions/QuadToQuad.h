#pragma once
#include "../Objects.h"
#include "BallToBall.h"
#include "BallToLine.h"
void QuadToQuadCollision(cube* quad1, cube* quad2);
bool QuadToQuadCollisionCheck(cube* quad1, cube* quad2);